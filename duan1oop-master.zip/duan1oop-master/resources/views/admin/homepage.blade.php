@extends('layout.index')
@section('title')
    <title>Trang chủ</title>
@endsection
@section('content')
    <h2 class="py-4 title-admin">Trang chủ</h2>
@endsection
