
<?php $__env->startSection('title'); ?>
    <title>Trang chủ</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h2 class="py-4 title-admin">Trang chủ</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ADMIN\Desktop\duan1-oop\resources\views\admin/homepage.blade.php ENDPATH**/ ?>